#ifndef EE_DISPLAY_H
#define EE_DISPLAY_H

#include "Adafruit_NeoPixel.h"

#define DISPLAYLIBVERSION 0x1
#define NUM_RGBARY 5


class EEDisplay
{
    public:
	void rgbSetup(int pin, int numpixels, Adafruit_NeoPixel * neopixel);
	void rgbShow(int pin, int pix, int r, int g, int b);
	void rgbBrightness(int pin, int brightness);
	void rgbOff(int pin);
	
	void lcdSetup(unsigned char addr);
	void lcdPrint(const char * str);
	void lcdPrint(int v);
	void lcdBacklight(unsigned char onoff);
	void lcdClear(void);
	void lcdCursor(uint8_t col, uint8_t row);
	
	void digiTubeSetup(int dat, int clk);
	void digiTubeShow(int num);
	void digiTubeOff();

    void parseDisplayCommand(char * cmd);
    
};

#endif

