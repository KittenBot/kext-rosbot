#include "config.h"
#include "Arduino.h"
#include "EEDisplay.h"


#ifdef USERGB
struct RGBMap{
	Adafruit_NeoPixel * rgb;
	int pin;
	int numpixels;
};
int rgbIdx;
RGBMap rgbAry[NUM_RGBARY];
void EEDisplay::rgbSetup(int pin, int numpixels, Adafruit_NeoPixel * neopix){
	neopix->begin();
	neopix->setPin(pin);
	neopix->setBrightness(100);
	rgbAry[rgbIdx].rgb = neopix;
	rgbAry[rgbIdx].pin = pin;
	rgbAry[rgbIdx].numpixels = numpixels;
	rgbIdx++;
}

void EEDisplay::rgbShow(int pin, int pix, int red, int green, int blue){
	for(int i=0;i<NUM_RGBARY;i++){
		if(rgbAry[i].pin == pin){
			if (pix == 0){
				for(int j=0;j<rgbAry[i].numpixels;j++){
					rgbAry[i].rgb->setPixelColor(j, red, green, blue);	
				}
				rgbAry[i].rgb->show();	
			} else {
				rgbAry[i].rgb->setPixelColor(pix-1, red, green, blue);
				rgbAry[i].rgb->show();	
			}
			break;
		}
	}
}

void EEDisplay::rgbOff(int pin){
	for(int i=0;i<NUM_RGBARY;i++){
		if(rgbAry[i].pin == pin){
			rgbAry[i].rgb->clear();
			rgbAry[i].rgb->show();
			break;
		}
	}
}

void EEDisplay::rgbBrightness(int pin, int brightness){
	for(int i=0;i<NUM_RGBARY;i++){
		if(rgbAry[i].pin == pin){
			rgbAry[i].rgb->setBrightness(brightness);
			break;
		}
	}
}
#endif

#ifdef USELCD

#include <LCD.h>
#include <LiquidCrystal_I2C.h> 
// todo: adapt to different lcd driver chip?
#define I2C_ADDR    0x3F
#define BACKLIGHT_PIN     3
#define En_pin  2
#define Rw_pin  1
#define Rs_pin  0
#define D4_pin  4
#define D5_pin  5
#define D6_pin  6
#define D7_pin  7

LiquidCrystal_I2C lcd(I2C_ADDR,En_pin,Rw_pin,Rs_pin,D4_pin,D5_pin,D6_pin,D7_pin);

void EEDisplay::lcdSetup(unsigned char addr){
	lcd.config(addr,En_pin,Rw_pin,Rs_pin,D4_pin,D5_pin,D6_pin,D7_pin);
	lcd.begin(16,2);
	lcd.setBacklightPin(BACKLIGHT_PIN,POSITIVE);
	lcd.setBacklight(1);
}

void EEDisplay::lcdPrint(const char * str){
	lcd.print(str);
}

void EEDisplay::lcdPrint(int v){
	lcd.print(v);
}


void EEDisplay::lcdBacklight(unsigned char onoff){
	lcd.setBacklight(onoff);
}

void EEDisplay::lcdCursor(uint8_t col, uint8_t row){
	lcd.setCursor ( col, row ); 
}

void EEDisplay::lcdClear(){
	lcd.clear();
}

#endif


#ifdef USEDIGITUBE
#include <TM1637Display.h>

TM1637Display digiTube;

void EEDisplay::digiTubeSetup(int dat, int clk){
	digiTube.setPins(clk, dat);
	digiTube.setBrightness(0x0f);
}

void EEDisplay::digiTubeShow(int num){
	digiTube.showNumberDec(num);
}

void EEDisplay::digiTubeOff(){
	uint8_t data[] = { 0, 0, 0, 0 };
	digiTube.setSegments(data);
}


#endif

void EEDisplay::parseDisplayCommand(char * cmd){
	char * tmp;
	if(cmd[0] == 'D'){
		cmd+=1;
		int code = atoi(cmd);
		cmd = strtok_r(cmd, " ", &tmp);
		switch(code){
		  case 0:
			Serial.println("D0 "+String(DISPLAYLIBVERSION));
			break;
#ifdef USERGB
		  case 1: // set rgb
			{
			  int pin;
			  sscanf(tmp, "%d", &pin);
			  // ledSetup(pin);
			}
			break;
		  case 2: // led display
			{
			  int pin, pix, r, g, b;
			  sscanf(tmp, "%d %d %d %d %d", &pin, &pix, &r, &g, &b);
			  rgbShow(pin, pix, r, g, b);
			}
			break;        
#endif
#ifdef USELCD
		  case 3: // lcd print
			{
			  lcdPrint(tmp);
			}
			break;
		  case 4: // led display
			{
			  int onoff;
			  sscanf(tmp, "%d", &onoff);
			  lcdBacklight(onoff);
			}
			break;  

#endif

		}
	}
}
